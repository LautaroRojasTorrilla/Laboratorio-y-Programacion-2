﻿namespace View
{
    partial class FrmView
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtDniCliente = new TextBox();
            cmbGuarnicion = new ComboBox();
            cmbIngredientes = new ComboBox();
            lblGuarnicion = new Label();
            lblIngredientes = new Label();
            btnAgregarIngrediente = new Button();
            lstHamburguesas = new ListBox();
            lblHamburguesa = new Label();
            grpIngredientes = new GroupBox();
            rdbGuarnicion = new RadioButton();
            rdbHamburguesa = new RadioButton();
            rchTicket = new RichTextBox();
            btnAgregarGuarnicion = new Button();
            grpIngredientes.SuspendLayout();
            SuspendLayout();
            // 
            // txtDniCliente
            // 
            txtDniCliente.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            txtDniCliente.Location = new Point(12, 34);
            txtDniCliente.Name = "txtDniCliente";
            txtDniCliente.PlaceholderText = "Dni del cliente";
            txtDniCliente.Size = new Size(161, 34);
            txtDniCliente.TabIndex = 0;
            txtDniCliente.TextChanged += txtDniCliente_TextChanged;
            txtDniCliente.Leave += txtDniCliente_Leave;
            // 
            // cmbGuarnicion
            // 
            cmbGuarnicion.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            cmbGuarnicion.FormattingEnabled = true;
            cmbGuarnicion.Location = new Point(12, 213);
            cmbGuarnicion.Name = "cmbGuarnicion";
            cmbGuarnicion.Size = new Size(227, 36);
            cmbGuarnicion.TabIndex = 1;
            cmbGuarnicion.SelectedIndexChanged += cmbGuarnicion_SelectedIndexChanged;
            // 
            // cmbIngredientes
            // 
            cmbIngredientes.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            cmbIngredientes.FormattingEnabled = true;
            cmbIngredientes.Location = new Point(6, 139);
            cmbIngredientes.Name = "cmbIngredientes";
            cmbIngredientes.Size = new Size(196, 36);
            cmbIngredientes.TabIndex = 2;
            // 
            // lblGuarnicion
            // 
            lblGuarnicion.AutoSize = true;
            lblGuarnicion.Font = new Font("Segoe UI", 13F, FontStyle.Bold, GraphicsUnit.Point);
            lblGuarnicion.Location = new Point(12, 185);
            lblGuarnicion.Name = "lblGuarnicion";
            lblGuarnicion.Size = new Size(227, 25);
            lblGuarnicion.TabIndex = 3;
            lblGuarnicion.Text = "Seleccione su guarnicion:";
            // 
            // lblIngredientes
            // 
            lblIngredientes.AutoSize = true;
            lblIngredientes.Font = new Font("Segoe UI", 13F, FontStyle.Bold, GraphicsUnit.Point);
            lblIngredientes.Location = new Point(16, 111);
            lblIngredientes.Name = "lblIngredientes";
            lblIngredientes.Size = new Size(124, 25);
            lblIngredientes.TabIndex = 4;
            lblIngredientes.Text = "Ingredientes:";
            // 
            // btnAgregarIngrediente
            // 
            btnAgregarIngrediente.Location = new Point(208, 139);
            btnAgregarIngrediente.Name = "btnAgregarIngrediente";
            btnAgregarIngrediente.Size = new Size(36, 36);
            btnAgregarIngrediente.TabIndex = 6;
            btnAgregarIngrediente.Text = "+";
            btnAgregarIngrediente.UseVisualStyleBackColor = true;
            btnAgregarIngrediente.Click += btnAgregarIngrediente_Click;
            // 
            // lstHamburguesas
            // 
            lstHamburguesas.FormattingEnabled = true;
            lstHamburguesas.ItemHeight = 15;
            lstHamburguesas.Location = new Point(12, 102);
            lstHamburguesas.Name = "lstHamburguesas";
            lstHamburguesas.Size = new Size(269, 64);
            lstHamburguesas.TabIndex = 7;
            lstHamburguesas.MouseDoubleClick += lstHamburguesas_MouseDoubleClick;
            // 
            // lblHamburguesa
            // 
            lblHamburguesa.AutoSize = true;
            lblHamburguesa.Font = new Font("Segoe UI", 13F, FontStyle.Bold, GraphicsUnit.Point);
            lblHamburguesa.Location = new Point(12, 74);
            lblHamburguesa.Name = "lblHamburguesa";
            lblHamburguesa.Size = new Size(252, 25);
            lblHamburguesa.TabIndex = 8;
            lblHamburguesa.Text = "Seleccione su hamburguesa:";
            // 
            // grpIngredientes
            // 
            grpIngredientes.Controls.Add(rdbGuarnicion);
            grpIngredientes.Controls.Add(rdbHamburguesa);
            grpIngredientes.Controls.Add(cmbIngredientes);
            grpIngredientes.Controls.Add(btnAgregarIngrediente);
            grpIngredientes.Controls.Add(lblIngredientes);
            grpIngredientes.Location = new Point(304, 74);
            grpIngredientes.Name = "grpIngredientes";
            grpIngredientes.Size = new Size(267, 186);
            grpIngredientes.TabIndex = 9;
            grpIngredientes.TabStop = false;
            grpIngredientes.Text = "Ingredientes";
            // 
            // rdbGuarnicion
            // 
            rdbGuarnicion.AutoSize = true;
            rdbGuarnicion.Location = new Point(16, 53);
            rdbGuarnicion.Name = "rdbGuarnicion";
            rdbGuarnicion.Size = new Size(83, 19);
            rdbGuarnicion.TabIndex = 1;
            rdbGuarnicion.Text = "Guarnicion";
            rdbGuarnicion.UseVisualStyleBackColor = true;
            // 
            // rdbHamburguesa
            // 
            rdbHamburguesa.AutoSize = true;
            rdbHamburguesa.Checked = true;
            rdbHamburguesa.Location = new Point(16, 22);
            rdbHamburguesa.Name = "rdbHamburguesa";
            rdbHamburguesa.Size = new Size(100, 19);
            rdbHamburguesa.TabIndex = 0;
            rdbHamburguesa.TabStop = true;
            rdbHamburguesa.Text = "Hamburguesa";
            rdbHamburguesa.UseVisualStyleBackColor = true;
            // 
            // rchTicket
            // 
            rchTicket.Location = new Point(12, 266);
            rchTicket.Name = "rchTicket";
            rchTicket.Size = new Size(556, 177);
            rchTicket.TabIndex = 10;
            rchTicket.Text = "";
            // 
            // btnAgregarGuarnicion
            // 
            btnAgregarGuarnicion.Location = new Point(245, 213);
            btnAgregarGuarnicion.Name = "btnAgregarGuarnicion";
            btnAgregarGuarnicion.Size = new Size(36, 36);
            btnAgregarGuarnicion.TabIndex = 11;
            btnAgregarGuarnicion.Text = "+";
            btnAgregarGuarnicion.UseVisualStyleBackColor = true;
            btnAgregarGuarnicion.Click += btnAgregarGuarnicion_Click;
            // 
            // FrmView
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(595, 450);
            Controls.Add(btnAgregarGuarnicion);
            Controls.Add(rchTicket);
            Controls.Add(grpIngredientes);
            Controls.Add(lblHamburguesa);
            Controls.Add(lstHamburguesas);
            Controls.Add(lblGuarnicion);
            Controls.Add(cmbGuarnicion);
            Controls.Add(txtDniCliente);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MinimizeBox = false;
            Name = "FrmView";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Hamburgueseria Alumno Div 2C";
            Load += FrmView_Load;
            grpIngredientes.ResumeLayout(false);
            grpIngredientes.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtDniCliente;
        private ComboBox cmbGuarnicion;
        private ComboBox cmbIngredientes;
        private Label lblGuarnicion;
        private Label lblIngredientes;
        private Button btnAgregarIngrediente;
        private ListBox lstHamburguesas;
        private Label lblHamburguesa;
        private GroupBox grpIngredientes;
        private RadioButton rdbGuarnicion;
        private RadioButton rdbHamburguesa;
        private RichTextBox rchTicket;
        private Button btnAgregarGuarnicion;
    }
}