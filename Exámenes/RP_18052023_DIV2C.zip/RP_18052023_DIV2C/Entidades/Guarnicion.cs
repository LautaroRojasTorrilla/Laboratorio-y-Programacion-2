﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Guarnicion : Comida
    {
        public enum ETipo { PAPAS_FRITAS = 1000, ENSALADA_RUSA = 750, ENSALADA_MIXTA = 500 };
        private ETipo tipo;

        public Guarnicion() : this(ETipo.PAPAS_FRITAS) { }
        public Guarnicion(ETipo tipo) : base(tipo.ToString())
        {
            this.tipo = tipo;
        }

        protected override double CalcularCosto()
        {
            double costo = (int)this.tipo;
            base.ingredientes.ForEach(ingrediente => costo += (costo * (int)ingrediente / 100));
            return costo;
        }

        protected override string MostrarDatos()
        {
            return $"{this.ToString()}\n{base.MostrarDatos()}";
        }

        protected override string AgregarIngrediente(EIngredientes ingrediente)
        {
            if ((Comida)this != ingrediente && this == ingrediente)
            {
                base.ingredientes.Add(ingrediente);
                return $"Se agrego {ingrediente} a su guarnicion";
            }

            return $"No se pudo agregar {ingrediente} a su guarnicion";
        }


        public static bool operator ==(Guarnicion g, EIngredientes ingrediente)
        {
            return ingrediente == EIngredientes.PANCETA || ingrediente == EIngredientes.ADHERESO || ingrediente == EIngredientes.QUESO;
        }
        public static bool operator !=(Guarnicion g, EIngredientes ingrediente)
        {
            return !(g == ingrediente);
        }

        public static explicit operator Guarnicion(Guarnicion.ETipo tipo)
        {
            return new Guarnicion(tipo);
        }

        public override string ToString()
        {
            return $"Guarnicion de tipo {this.tipo}";
        }


    }
}
