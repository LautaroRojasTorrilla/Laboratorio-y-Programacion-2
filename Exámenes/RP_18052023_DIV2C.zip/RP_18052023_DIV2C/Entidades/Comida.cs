﻿using System.Text;

namespace Entidades
{
    public abstract class Comida
    {
        public enum EIngredientes { ADHERESO, QUESO=10, CEBOLLA=8, LECHUGA=7, TOMATE=9, JAMON=12, HUEVO=13, PANCETA =15};
        private string nombre;
        protected List<EIngredientes> ingredientes;


        protected Comida(string nombre) : this(nombre, new List<EIngredientes>()) { }
        protected Comida(string nombre, List<EIngredientes> ingredientes)
        {
            this.nombre = nombre;
            this.ingredientes = ingredientes;
        }

        public double Costo { get => this.CalcularCosto(); }

        public string Descripcion { get => this.MostrarDatos(); }
        public string Nombre { get => nombre; set => nombre = value; }

        protected virtual string MostrarDatos()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendLine($"Nombre: {this.nombre}");
            stringBuilder.AppendLine("Ingredientes: ");
            this.ingredientes.ForEach(i => stringBuilder.AppendLine(i.ToString()));
            stringBuilder.AppendLine($"Costo: {this.Costo}");
            return stringBuilder.ToString();
        }

        protected abstract double CalcularCosto();


        protected abstract string AgregarIngrediente(EIngredientes ingrediente);


        public static bool operator ==(Comida c, EIngredientes ingrediente)
        {
            return c.ingredientes.Exists(e => e == ingrediente);
        }

        public static bool operator !=(Comida c, EIngredientes ingrediente)
        {
            return !(c == ingrediente);
        }

        public override bool Equals(object? obj)
        {
            return obj is not null &&  obj is Comida && ((Comida)obj).nombre == this.nombre;
        }

        public static string operator +(Comida c, EIngredientes ingrediente)
        {
            return c.AgregarIngrediente(ingrediente);
        }
    }
}