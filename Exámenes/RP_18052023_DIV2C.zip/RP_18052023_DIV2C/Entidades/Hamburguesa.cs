﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Hamburguesa:Comida
    {

        private static double costoBase;
        private bool esDoble;

        static Hamburguesa()
        {
            Hamburguesa.costoBase = 1500;
        }

        public Hamburguesa(string nombre) : base(nombre)
        {
        }
        public Hamburguesa(string nombre, bool esDoble) : this(nombre)
        {
            this.esDoble = esDoble;
        }

        protected override string AgregarIngrediente(EIngredientes ingrediente)
        {
            if (this != ingrediente)
            {
                base.ingredientes.Add(ingrediente);
                return $"Se agrego {ingrediente} a su hamburguesa";
            }

            return $"No se pudo agregar {ingrediente} a su hamburguesa";
        }

        protected override string MostrarDatos()
        {
            return $"{this.ToString()}\n{base.MostrarDatos()}";
        }

        protected override double CalcularCosto()
        {
            double costo = this.esDoble ? Hamburguesa.costoBase+500 : Hamburguesa.costoBase;
            base.ingredientes.ForEach(ingrediente => costo +=  (costo * (int)ingrediente/100));
            return costo;
        }

        public override string ToString()
        {
            return $"Hamburguesa {(this.esDoble ? "Doble" : "Simple")}";
        }

    }
}
