﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Cliente
    {
        private List<Comida> menu;
        private int dni;


        private Cliente(int dni)
        {
            this.dni = dni;
            this.menu = new List<Comida>();
        }

        public static Cliente GetCliente(int dni)
        {
            return dni;
        }
        public Comida BuscarComida(Comida comida)
        {
            return this.menu.Find(c => c.Equals(comida));
        }
        public static string ImprimirTicket(Cliente cliente)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"cliente: {cliente.dni}");
            sb.AppendLine($"*****Menu*****");
            cliente.menu.ForEach(c=> sb.AppendLine(c.Descripcion));
            sb.AppendLine($"Total a pagar:\n {cliente.TotalAPagar}");
            return sb.ToString();
        }

        public static Cliente operator +(Cliente cliente, Comida comida)
        {
            cliente.menu.Add(comida);
            return cliente;

        }

        private double TotalAPagar
        {
            get
            {
                double totalAPagar = 0;
                this.menu.ForEach(c => totalAPagar += c.Costo);
                return totalAPagar;
            }
  
        }

        public static bool operator == (Cliente cliente, Comida comida)
        {
            return cliente.menu.Contains(comida);
        }
        public static bool operator !=(Cliente cliente, Comida comida)
        {
            return !(cliente == comida);
        }


        public static implicit operator Cliente(int dni)
        {
            return new Cliente(dni);
        }

    }
}
