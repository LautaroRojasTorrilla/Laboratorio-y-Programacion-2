using Entidades;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        private Fabrica mermeladas;

        public Form1()
        {
            InitializeComponent();
            mermeladas = new Fabrica(3);
            Manzana manzana = new Manzana(Aditivos.Canela);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbSabor.Items.Add("Pera");
            cmbSabor.Items.Add("Manzana");
            cmbSabor.Items.Add("Tomate");
        }

        private void Refrescar()
        {
            lstItems.Items.Clear();

            foreach (Mermelada frasco in mermeladas.Frascos)
            {
                lstItems.Items.Add(frasco.GetInfo());
            }
        }

        private void btnFabricar_Click(object sender, EventArgs e)
        {
            string saborSeleccionado = this.cmbSabor.SelectedItem as string; 

            if (!string.IsNullOrEmpty(saborSeleccionado))
            {
                Mermelada frasco = null;

                switch (saborSeleccionado)
                {
                    case "Manzana":
                        frasco = new Manzana(Aditivos.Mascabo);
                        this.Refrescar();
                        break;
                    case "Pera":
                        frasco = new Pera(Aditivos.Canela);
                        this.Refrescar();
                        break;
                    case "Tomate":
                        frasco = new Tomate("Familiar");
                        this.Refrescar();
                        break;
                    default:
                        break;
                }

                if (frasco != null)
                {
                    this.mermeladas += frasco;
                    this.Refrescar();
                }
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            string saborSeleccionado = this.cmbSabor.SelectedItem as string; 

            if (!string.IsNullOrEmpty(saborSeleccionado))
            {
                Mermelada frasco = null;

                switch (saborSeleccionado)
                {
                    case "Manzana":
                        frasco = new Manzana(Aditivos.Mascabo);
                        this.Refrescar();
                        break;
                    case "Pera":
                        frasco = new Pera(Aditivos.Canela);
                        this.Refrescar();
                        break;
                    case "Tomate":
                        frasco = new Tomate("Familiar");
                        this.Refrescar();
                        break;
                    default:
                        break;
                }

                if (frasco != null)
                {
                    this.mermeladas -= frasco;
                    this.Refrescar();
                }
            }
        }
    }
}