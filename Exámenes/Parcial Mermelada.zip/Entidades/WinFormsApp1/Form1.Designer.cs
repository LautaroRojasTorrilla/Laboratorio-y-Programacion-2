﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            btnFabricar = new Button();
            btnEliminar = new Button();
            lblSabor = new Label();
            cmbSabor = new ComboBox();
            lstItems = new ListBox();
            picFrasco = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)picFrasco).BeginInit();
            SuspendLayout();
            // 
            // btnFabricar
            // 
            btnFabricar.Location = new Point(572, 261);
            btnFabricar.Name = "btnFabricar";
            btnFabricar.Size = new Size(200, 38);
            btnFabricar.TabIndex = 0;
            btnFabricar.Text = "FABRICAR";
            btnFabricar.UseVisualStyleBackColor = true;
            btnFabricar.Click += btnFabricar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Location = new Point(572, 318);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(200, 38);
            btnEliminar.TabIndex = 1;
            btnEliminar.Text = "ELIMINAR";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // lblSabor
            // 
            lblSabor.AutoSize = true;
            lblSabor.Location = new Point(572, 40);
            lblSabor.Name = "lblSabor";
            lblSabor.Size = new Size(37, 15);
            lblSabor.TabIndex = 2;
            lblSabor.Text = "Sabor";
            // 
            // cmbSabor
            // 
            cmbSabor.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbSabor.FormattingEnabled = true;
            cmbSabor.Location = new Point(572, 58);
            cmbSabor.Name = "cmbSabor";
            cmbSabor.Size = new Size(200, 23);
            cmbSabor.TabIndex = 3;
            // 
            // lstItems
            // 
            lstItems.FormattingEnabled = true;
            lstItems.ItemHeight = 15;
            lstItems.Location = new Point(12, 31);
            lstItems.Name = "lstItems";
            lstItems.Size = new Size(510, 334);
            lstItems.TabIndex = 4;
            // 
            // picFrasco
            // 
            picFrasco.Image = (Image)resources.GetObject("picFrasco.Image");
            picFrasco.Location = new Point(614, 108);
            picFrasco.Name = "picFrasco";
            picFrasco.Size = new Size(118, 124);
            picFrasco.TabIndex = 5;
            picFrasco.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            ClientSize = new Size(800, 450);
            Controls.Add(picFrasco);
            Controls.Add(lstItems);
            Controls.Add(cmbSabor);
            Controls.Add(lblSabor);
            Controls.Add(btnEliminar);
            Controls.Add(btnFabricar);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Mermelandia";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)picFrasco).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnFabricar;
        private Button btnEliminar;
        private Label lblSabor;
        private ComboBox cmbSabor;
        private ListBox lstItems;
        private PictureBox picFrasco;
    }
}