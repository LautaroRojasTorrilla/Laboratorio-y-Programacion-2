﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Fabrica
    {
        private int capacidad;
        private List<Mermelada> frascos;


        private Fabrica()
        {
            this.frascos = new List<Mermelada>();
        }

        public Fabrica(int capacidad) :this()
        {
            this.capacidad = capacidad;
        }

        public List<Mermelada> Frascos
        {
            get { return frascos; }
        }

        /// <summary>
        /// Sobrecarga del operador + para agregar un frasco de mermelada a la fábrica.
        /// </summary>
        /// <param name="fabrica">La instancia de la fábrica a la que se desea agregar el frasco.</param>
        /// <param name="frasco">El frasco de mermelada que se desea agregar a la fábrica.</param>
        /// <returns>La instancia de la fábrica con el frasco agregado, si hay espacio disponible.</returns>
        public static Fabrica operator +(Fabrica fabrica, Mermelada frasco)
        {
            if (fabrica.frascos.Count < fabrica.capacidad)
            {
                fabrica.frascos.Add(frasco);
            }
            return fabrica;
        }

        public static Fabrica operator -(Fabrica fabrica, Mermelada frasco)
        {
            Mermelada frascoEncontrado = fabrica.frascos.FirstOrDefault(f => f.GetType() == frasco.GetType());
            if (frascoEncontrado != null)
            {
                fabrica.frascos.Remove(frascoEncontrado);
            }
            return fabrica;
        }

    }
}
