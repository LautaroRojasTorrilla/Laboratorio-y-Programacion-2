﻿namespace Entidades
{
    public abstract class Mermelada
    {

        protected Aditivos aditivo;
        protected bool esOrganico;

        protected Mermelada(Aditivos aditivo) :this(aditivo, false) { }

        protected Mermelada(Aditivos aditivo, bool esOrganico)
        {
            this.aditivo = aditivo;
            this.esOrganico = esOrganico;
        }

        protected Aditivos Aditivo { get => aditivo; }

        public abstract string Tipo { get; }


        public virtual string GetInfo()
        {
            string organico = esOrganico ? "SI" : "NO";
            return string.Format("{0} con aditivo {1}, {2} es orgánica.", this.Tipo, this.Aditivo, organico);
        }

        public static bool operator ==(Mermelada m1, Mermelada m2)
        {
            if (Object.ReferenceEquals(m1, m2))
            {
                return true;
            }

            if (Object.ReferenceEquals(m1, null) || Object.ReferenceEquals(m2, null))
            {
                return false;
            }
            return m1.GetType() == m2.GetType();
        }

        public static bool operator !=(Mermelada m1, Mermelada m2)
        {
            return !(m1 == m2);
        }

    }
}