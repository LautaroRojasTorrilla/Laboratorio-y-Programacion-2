﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Tomate :Mermelada
    {
        private string receta;

        public Tomate(string receta) :base(Aditivos.Mascabo)
        {
            this.receta = receta;
        }

        private string Receta { get => receta; 
            set => receta = string.IsNullOrWhiteSpace(value) ? "Indefinida" : value; }

        public override string Tipo => "Mermelada de tomate";

        public override string GetInfo()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.GetInfo());
            sb.AppendLine($" * Receta: {this.Receta}");

            return sb.ToString();
        }


    }
}
