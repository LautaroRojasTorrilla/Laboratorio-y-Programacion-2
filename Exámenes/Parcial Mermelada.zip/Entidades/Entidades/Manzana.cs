﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Manzana : Mermelada
    {
        public Manzana(Aditivos aditivo) : base(aditivo)
        {

        }

        public override string Tipo => "Mermelada de manzana";
    }
}
