﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Cliente
    {
        private int dni;
        private List<Comida> menu;

        private Cliente(int dni)
        {
            this.dni = dni;
            this.menu = new List<Comida>();
        }

        public static implicit operator Cliente(int dni)
        {
            return new Cliente(dni);
        }

        public double TotalAPagar
        {
            get { return menu.Sum(comida => comida.Costo); }
        }


        public static Cliente GetCliente(int dni)
        {
            return new Cliente(dni);
        }
        
        public Comida BuscarComida(Comida comida)
        {
            foreach (Comida c in menu)
            {
                if (c.Nombre == comida.Nombre)
                {
                    return c;
                }
            }
            return null;
        }

        public static Cliente operator +(Cliente cliente, Comida comida)
        {
            cliente.menu.Add(comida);
            return cliente;
        }

        public string ImprimirTicket(Cliente cliente)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"DNI {cliente.dni}");

            sb.AppendLine("Menú:");

            foreach (Comida comida in cliente.menu)
            {
                sb.AppendLine(comida.Descripcion);
            }

            sb.AppendLine($"Total a pagar: {cliente.TotalAPagar}");

            return sb.ToString();
        }

        public static bool operator ==(Cliente cliente, Comida comida)
        {
            return cliente.menu.Contains(comida);
        }

        public static bool operator !=(Cliente cliente, Comida comida)
        {
            return !(cliente == comida);
        }
    }

}

