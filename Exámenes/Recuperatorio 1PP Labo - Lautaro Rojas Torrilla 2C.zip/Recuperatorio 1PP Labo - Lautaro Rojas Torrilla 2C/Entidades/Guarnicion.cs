﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public enum ETipo
    {
        PAPAS_FRITAS = 1000,
        ENSALADA_RUSA = 750,
        ENSALADA_MIXTA = 500
    }

    public class Guarnicion : Comida
    {
        private ETipo tipo;

        public Guarnicion() : base(string.Empty)
        {
            base.Nombre = ETipo.PAPAS_FRITAS.ToString();
        }

        public Guarnicion (ETipo tipo) : this()
        {
            this.tipo = tipo;
        }

        public static bool operator ==(Guarnicion g, Eingredientes ingrediente)
        {
            if (ingrediente == Eingredientes.PANCETA || ingrediente == Eingredientes.ADHERESO || ingrediente == Eingredientes.QUESO)
            {
                return true;
            }

            return false;
        }

        public static bool operator !=(Guarnicion g, Eingredientes ingrediente)
        {
            return !(g == ingrediente);
        }

        public static explicit operator Guarnicion(ETipo tipo)
        {
            return new Guarnicion(tipo);
        }

        protected override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.MostrarDatos());
            sb.AppendLine(this.ToString());

            return sb.ToString();
        }

        public override string ToString()
        {
            return $"Guarnicion de tipo { this.tipo}";
        }

        protected override string AgregarIngrediente(Eingredientes ingrediente)
        {
            if (ingredientes.Contains(ingrediente))
            {
                return $"No se pudo agregar {ingrediente} a su guarnicion";
            }

            if (this == ingrediente)
            {
                ingredientes.Add(ingrediente);
                return $"Se agrego {ingrediente} a su guarnicion";
            }

            return $"No se pudo agregar {ingrediente} a su guarnicion";
        }

        protected override double CalcularCosto()
        {
            double costoTotal = (double)tipo;

            foreach (var ingrediente in ingredientes)
            {
                switch (ingrediente)
                {
                    case Eingredientes.ADHERESO:
                        costoTotal += 0; 
                        break;
                    case Eingredientes.QUESO:
                        costoTotal += costoTotal * 0.1;
                        break;
                    case Eingredientes.PANCETA:
                        costoTotal += costoTotal * 0.15;
                        break;
                }
            }

            return costoTotal;
        }



    }
}
