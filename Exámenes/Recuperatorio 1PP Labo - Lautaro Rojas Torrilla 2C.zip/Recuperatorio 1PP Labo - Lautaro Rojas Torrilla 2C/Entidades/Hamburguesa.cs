﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Hamburguesa : Comida
    {
        private static double costoBase;
        private bool esDoble;

        static Hamburguesa()
        {
            costoBase = 1500;
        }

        public Hamburguesa(string nombre) : base(nombre) 
        { 
        
        }

        public Hamburguesa (string nombre, bool esDoble) :this (nombre)
        {
            this.esDoble = esDoble;
        }

        protected override string AgregarIngrediente(Eingredientes ingrediente)
        {
            if (!ingredientes.Contains(ingrediente))
            {
                ingredientes.Add(ingrediente);
                return $"Se agrego {ingrediente} a su hamburguesa";
            }
            else
            {
                return $"No se pudo agregar {ingrediente} a su hamburguesa";
            }
        }

        /// <summary>
        /// Retorna una cadena que representa los datos de la guarnición.
        /// </summary>
        /// <returns>Una cadena que contiene los datos de la guarnición.</returns>
        protected override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(this.ToString());
            sb.AppendLine(base.MostrarDatos());


            return sb.ToString();
        }

        public override string ToString()
        {
            string tipoHamburguesa = esDoble ? "Doble" : "Simple";
            return $"Hamburguesa - {tipoHamburguesa}";
        }

        protected override double CalcularCosto()
        {
            double costo = costoBase;

            if (esDoble)
            {
                costo += 500;
            }

            foreach (var ingrediente in ingredientes)
            {
                switch (ingrediente)
                {
                    case Eingredientes.ADHERESO:
                        costo += 0;
                        break;
                    case Eingredientes.LECHUGA:
                        costo += costoBase * 0.07;
                        break;
                    case Eingredientes.CEBOLLA:
                        costo += costoBase * 0.08;
                        break;
                    case Eingredientes.TOMATE:
                        costo += costoBase * 0.09;
                        break;
                    case Eingredientes.QUESO:
                        costo += costoBase * 0.1;
                        break;
                    case Eingredientes.JAMON:
                        costo += costoBase * 0.12;
                        break;
                    case Eingredientes.HUEVO:
                        costo += costoBase * 0.13;
                        break;
                    case Eingredientes.PANCETA:
                        costo += costoBase * 0.15;
                        break;
                }
            }
            return costo;
        }



    }
}
