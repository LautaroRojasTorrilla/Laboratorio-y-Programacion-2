﻿using System.Net;
using System.Text;

namespace Entidades
{

    public enum Eingredientes
    {
        ADHERESO,
        QUESO = 10,
        CEBOLLA = 8,
        LECHUGA = 7,
        TOMATE = 9,
        JAMON = 12,
        HUEVO =13,
        PANCETA = 15
    }

    public abstract class Comida
    {
        protected List<Eingredientes> ingredientes;
        private string nombre;

        protected Comida(string nombre)
        {
            this.nombre = nombre;
        }

        protected Comida(string nombre, List<Eingredientes> ingredientes) :this(nombre)
        {
            ingredientes = new List<Eingredientes>();
        }

        public double Costo
        {
            get { return this.CalcularCosto(); }
        }

        public string Descripcion
        {
            get { return this.MostrarDatos(); }
        }

        public string Nombre { get => nombre; set => nombre = value; }

        protected abstract double CalcularCosto();

        protected abstract string AgregarIngrediente(Eingredientes ingrediente);

        protected virtual string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Nombre: {Nombre}");
            sb.AppendLine($"Costo: {Costo}");
            //sb.AppendLine($"ingrediente: {});


            return sb.ToString();
        }

        public override bool Equals(object? obj)
        {
            if (obj is null || !(obj is Comida))
            {
                return false;
            }

            return (Comida)obj == this;
        }

        public static bool operator==(Comida c, Eingredientes ingrediente)
        {
            foreach (var ingrediente1 in c.ingredientes)
            {
                if (ingrediente1 == ingrediente)
                    return true;
            }
            return false;
        }

        public static bool operator !=(Comida c, Eingredientes ingrediente)
        {
            return !(c == ingrediente);
        }



        public static string operator +(Comida comida, Eingredientes ingrediente)
        {
            string mensaje = comida.AgregarIngrediente(ingrediente);
            
            return $"{comida.Descripcion}\n{mensaje}";
        }





    }
}