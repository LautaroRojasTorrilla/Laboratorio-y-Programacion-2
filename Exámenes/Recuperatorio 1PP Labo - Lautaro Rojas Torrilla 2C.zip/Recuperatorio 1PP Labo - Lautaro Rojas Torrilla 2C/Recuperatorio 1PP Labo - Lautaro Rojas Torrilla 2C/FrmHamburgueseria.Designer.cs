﻿namespace Recuperatorio_1PP_Labo___Lautaro_Rojas_Torrilla_2C
{
    partial class FrmHamburgueseria
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            richTextBox1 = new RichTextBox();
            textBox1 = new TextBox();
            lblHamburguesa = new Label();
            lstHamburguesas = new ListBox();
            comboBox1 = new ComboBox();
            button1 = new Button();
            lblGuarnicion = new Label();
            groupBox1 = new GroupBox();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            lblIngredientes = new Label();
            button2 = new Button();
            comboBox2 = new ComboBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(12, 311);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(533, 159);
            richTextBox1.TabIndex = 0;
            richTextBox1.Text = "";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(35, 26);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "DNI del cliente";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 1;
            // 
            // lblHamburguesa
            // 
            lblHamburguesa.AutoSize = true;
            lblHamburguesa.Location = new Point(35, 73);
            lblHamburguesa.Name = "lblHamburguesa";
            lblHamburguesa.Size = new Size(157, 15);
            lblHamburguesa.TabIndex = 2;
            lblHamburguesa.Text = "Seleccione su hamburguesa:";
            // 
            // lstHamburguesas
            // 
            lstHamburguesas.FormattingEnabled = true;
            lstHamburguesas.ItemHeight = 15;
            lstHamburguesas.Location = new Point(35, 102);
            lstHamburguesas.Name = "lstHamburguesas";
            lstHamburguesas.Size = new Size(157, 109);
            lstHamburguesas.TabIndex = 3;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(35, 261);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 4;
            // 
            // button1
            // 
            button1.Location = new Point(171, 261);
            button1.Name = "button1";
            button1.Size = new Size(21, 23);
            button1.TabIndex = 5;
            button1.Text = "+";
            button1.UseVisualStyleBackColor = true;
            // 
            // lblGuarnicion
            // 
            lblGuarnicion.AutoSize = true;
            lblGuarnicion.Location = new Point(35, 230);
            lblGuarnicion.Name = "lblGuarnicion";
            lblGuarnicion.Size = new Size(141, 15);
            lblGuarnicion.TabIndex = 6;
            lblGuarnicion.Text = "Seleccione su guarnicion:";
            // 
            // groupBox1
            // 
            groupBox1.AccessibleRole = AccessibleRole.MenuBar;
            groupBox1.Controls.Add(radioButton2);
            groupBox1.Controls.Add(radioButton1);
            groupBox1.Controls.Add(lblIngredientes);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(comboBox2);
            groupBox1.Location = new Point(261, 66);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(284, 228);
            groupBox1.TabIndex = 7;
            groupBox1.TabStop = false;
            groupBox1.Text = "Ingredientes";
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(29, 72);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(83, 19);
            radioButton2.TabIndex = 10;
            radioButton2.TabStop = true;
            radioButton2.Text = "Guarnición";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(29, 36);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(100, 19);
            radioButton1.TabIndex = 9;
            radioButton1.TabStop = true;
            radioButton1.Text = "Hamburguesa";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // lblIngredientes
            // 
            lblIngredientes.AutoSize = true;
            lblIngredientes.Location = new Point(29, 164);
            lblIngredientes.Name = "lblIngredientes";
            lblIngredientes.Size = new Size(75, 15);
            lblIngredientes.TabIndex = 8;
            lblIngredientes.Text = "Ingredientes:";
            // 
            // button2
            // 
            button2.Location = new Point(156, 195);
            button2.Name = "button2";
            button2.Size = new Size(21, 23);
            button2.TabIndex = 7;
            button2.Text = "+";
            button2.UseVisualStyleBackColor = true;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(29, 195);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(121, 23);
            comboBox2.TabIndex = 6;
            // 
            // FrmHamburgueseria
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(581, 482);
            Controls.Add(groupBox1);
            Controls.Add(lblGuarnicion);
            Controls.Add(button1);
            Controls.Add(comboBox1);
            Controls.Add(lstHamburguesas);
            Controls.Add(lblHamburguesa);
            Controls.Add(textBox1);
            Controls.Add(richTextBox1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmHamburgueseria";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Hamburgueseria Rojas Torrilla Div 2C";
            Load += FrmHamburgueseria_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox richTextBox1;
        private TextBox textBox1;
        private Label lblHamburguesa;
        private ListBox lstHamburguesas;
        private ComboBox comboBox1;
        private Button button1;
        private Label lblGuarnicion;
        private GroupBox groupBox1;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private Label lblIngredientes;
        private Button button2;
        private ComboBox comboBox2;
    }
}