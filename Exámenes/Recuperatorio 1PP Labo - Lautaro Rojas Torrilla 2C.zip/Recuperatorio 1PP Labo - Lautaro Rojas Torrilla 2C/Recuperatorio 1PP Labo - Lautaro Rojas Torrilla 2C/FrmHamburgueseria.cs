using Entidades;
using System.Drawing;
using System;

namespace Recuperatorio_1PP_Labo___Lautaro_Rojas_Torrilla_2C
{
    public partial class FrmHamburgueseria : Form
    {
        public FrmHamburgueseria()
        {
            InitializeComponent();
        }

        private void FrmHamburgueseria_Load(object sender, EventArgs e)
        {
            //this.cmbGuarnicion.DataSource = Enum.GetValues(typeof(Guarnicion.ETipo));
            //this.cmbIngredientes.DataSource =
            //Enum.GetValues(typeof(Comida.EIngredientes));
            //this.cmbGuarnicion.SelectedItem =
            //Guarnicion.ETipo.PAPAS_FRITAS;
            //this.lstHamburguesas.DataSource = new
            //List<Hamburguesa>() { new Hamburguesa("Simple con queso"), new Hamburguesa("Doble con queso", true) };
        }
    }
}