﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recu_primer_parcial
{
    public class Cliente
    {
        private int dni;
        private List<Comida> menu;

        private Cliente(int dni) { this.dni = dni; }

        private double TotalAPagar
        {
            get
            {
                double total = 0;
                foreach (Comida comida in this.menu)
                {
                    total += comida.Costo;
                }
                return total;
            }
        }

        static Cliente GetCliente(int dni)
        {
            Cliente cliente = dni;
            return cliente;
        }

        public static implicit operator Cliente(int dni) {  return new Cliente(dni); }

        public static bool operator +(Cliente cliente, Comida comida)
        {
            if (cliente.BuscarComida(comida) == null)
            {
                cliente.menu.Add(comida);
                return true;
            }
            else
            {
                return false;
            }
        }

        public Comida BuscarComida(Comida comida)
        {
            foreach (Comida c in menu)
            {
                if (c.Equals(comida))
                {
                    return c;
                }
            }
            return null;
        }

        public string ImprimirTicket(Cliente cliente)
        {
            StringBuilder sb = new StringBuilder();

            // Datos del cliente
            sb.AppendLine($"Cliente: DNI {cliente.dni}");

            // Menú del cliente
            sb.AppendLine("Menú:");
            foreach (Comida comida in cliente.menu)
            {
                sb.AppendLine(comida.Descripcion);
            }

            // Total a pagar
            sb.AppendLine($"Total a pagar: {cliente.TotalAPagar}");

            return sb.ToString();
        }

        public static bool operator ==(Cliente cliente, Comida comida)
        {
            return cliente.menu.Contains(comida);
        }
        public static bool operator !=(Cliente cliente, Comida comida)
        {
            return !(cliente == comida);
        }

    }
}
